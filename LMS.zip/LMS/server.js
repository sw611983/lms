const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json());

let library = [
    { id: 1, title: 'Book A', copies: 3 },
    { id: 2, title: 'Book B', copies: 1 }
];

let users = {
    user1: { borrowedBooks: [] }
};

const MAX_BORROW_LIMIT = 2;

app.get('/books', (req, res) => {
    res.json(library);
});

app.post('/borrow', (req, res) => {
    const { userId, bookId } = req.body;
    const user = users[userId];
    const book = library.find(b => b.id === bookId);

    if (!book) {
        return res.status(404).json({ message: 'Book not found' });
    }

    if (user.borrowedBooks.length >= MAX_BORROW_LIMIT) {
        return res.status(400).json({ message: 'Borrow limit reached' });
    }

    if (book.copies > 0) {
        user.borrowedBooks.push(bookId);
        book.copies -= 1;
        if (book.copies === 0) {
            library = library.filter(b => b.id !== bookId);
        }
        res.json({ message: 'Book borrowed successfully' });
    } else {
        res.status(400).json({ message: 'No copies left' });
    }
});

app.post('/return', (req, res) => {
    const { userId, bookId } = req.body;
    const user = users[userId];
    const book = library.find(b => b.id === bookId);

    if (!user.borrowedBooks.includes(bookId)) {
        return res.status(400).json({ message: 'Book not borrowed' });
    }

    user.borrowedBooks = user.borrowedBooks.filter(id => id !== bookId);
    if (book) {
        book.copies += 1;
    } else {
        library.push({ id: bookId, title: `Book ${bookId}`, copies: 1 });
    }
    res.json({ message: 'Book returned successfully' });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
