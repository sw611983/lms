import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
    const [books, setBooks] = useState([]);
    const [borrowedBooks, setBorrowedBooks] = useState([]);
    const [selectedBookId, setSelectedBookId] = useState('');
    const userId = 'user1';

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        const response = await axios.get('http://localhost:3000/books');
        setBooks(response.data);
    };

    const borrowBook = async () => {
        try {
            await axios.post('http://localhost:3000/borrow', { userId, bookId: parseInt(selectedBookId) });
            fetchBooks();
        } catch (error) {
            console.error('Error borrowing book', error);
        }
    };

    const returnBook = async (bookId) => {
        try {
            await axios.post('http://localhost:3000/return', { userId, bookId });
            fetchBooks();
        } catch (error) {
            console.error('Error returning book', error);
        }
    };

    return (
        <div>
            <h1>Library</h1>
            <ul>
                {books.map(book => (
                    <li key={book.id}>
                        {book.title} - Copies: {book.copies}
                        <button onClick={() => setSelectedBookId(book.id)}>Select</button>
                    </li>
                ))}
            </ul>
            <button onClick={borrowBook}>Borrow Book</button>
            <h2>Borrowed Books</h2>
            <ul>
                {borrowedBooks.map(bookId => (
                    <li key={bookId}>
                        {books.find(b => b.id === bookId)?.title}
                        <button onClick={() => returnBook(bookId)}>Return Book</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default App;
